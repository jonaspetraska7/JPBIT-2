import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kontaktai',
  templateUrl: './kontaktai.component.html',
  styleUrls: ['./kontaktai.component.css']
})
export class KontaktaiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
