import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meniu',
  templateUrl: './meniu.component.html',
  styleUrls: ['./meniu.component.css']
})
export class MeniuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
